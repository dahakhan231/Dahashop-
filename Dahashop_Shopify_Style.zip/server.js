
const express = require("express");
const session = require("express-session");
const pgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const path = require("path");

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false });

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.use(session({
  store: new pgSession({ pool, tableName: "user_sessions", createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET || "change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 }
}));

async function init() {
  const fs = require("fs");
  await pool.query(fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8"));
  if (process.env.ADMIN_PASSWORD) {
    await pool.query("UPDATE users SET password=$1 WHERE email='admin@dahashop.com'", [process.env.ADMIN_PASSWORD]);
  }
}
init().catch(console.error);

function requireLogin(req,res,next){
  if(!req.session.user) return res.redirect("/login");
  next();
}
function requireAdmin(req,res,next){
  if(!req.session.user || req.session.user.role !== "admin") return res.status(403).send("Admin access required");
  next();
}

app.get("/", async (req,res)=>{
  const q = req.query.q || "";
  const {rows: products} = await pool.query(
    "SELECT * FROM products WHERE name ILIKE $1 OR category ILIKE $1 ORDER BY created_at DESC",
    [`%${q}%`]
  );
  res.render("home",{products,user:req.session.user,q});
});

app.get("/login",(req,res)=>res.render("login",{error:null}));
app.post("/login",async(req,res)=>{
  const {email,password}=req.body;
  const {rows}=await pool.query("SELECT id,name,email,role FROM users WHERE email=$1 AND password=$2",[email,password]);
  if(!rows.length) return res.render("login",{error:"Email or password is incorrect"});
  req.session.user=rows[0];
  res.redirect(rows[0].role==="admin"?"/admin":"/");
});

app.get("/signup",(req,res)=>res.render("signup",{error:null}));
app.post("/signup",async(req,res)=>{
  try{
    const {name,email,password}=req.body;
    const r=await pool.query("INSERT INTO users(name,email,password) VALUES($1,$2,$3) RETURNING id,name,email,role",[name,email,password]);
    req.session.user=r.rows[0]; res.redirect("/");
  }catch(e){res.render("signup",{error:"Email already exists"});}
});

app.post("/logout",(req,res)=>req.session.destroy(()=>res.redirect("/")));

app.get("/admin",requireAdmin,async(req,res)=>{
  const [p,o,u]=await Promise.all([
    pool.query("SELECT * FROM products ORDER BY created_at DESC"),
    pool.query("SELECT * FROM orders ORDER BY created_at DESC"),
    pool.query("SELECT id,name,email,role,created_at FROM users ORDER BY created_at DESC")
  ]);
  res.render("admin",{user:req.session.user,products:p.rows,orders:o.rows,users:u.rows});
});

app.post("/admin/product",requireAdmin,async(req,res)=>{
  const {name,description,price,image_url,category,stock}=req.body;
  await pool.query("INSERT INTO products(name,description,price,image_url,category,stock) VALUES($1,$2,$3,$4,$5,$6)",
    [name,description,price,image_url,category,stock]);
  res.redirect("/admin");
});

app.post("/admin/product/:id/delete",requireAdmin,async(req,res)=>{
  await pool.query("DELETE FROM products WHERE id=$1",[req.params.id]);
  res.redirect("/admin");
});

app.post("/admin/order/:id/status",requireAdmin,async(req,res)=>{
  await pool.query("UPDATE orders SET status=$1 WHERE id=$2",[req.body.status,req.params.id]);
  res.redirect("/admin");
});

app.get("/product/:id",async(req,res)=>{
  const r=await pool.query("SELECT * FROM products WHERE id=$1",[req.params.id]);
  if(!r.rows.length) return res.status(404).send("Product not found");
  res.render("product",{product:r.rows[0],user:req.session.user});
});

app.post("/order",requireLogin,async(req,res)=>{
  const {product_id,quantity,address,phone}=req.body;
  const p=await pool.query("SELECT * FROM products WHERE id=$1",[product_id]);
  if(!p.rows.length) return res.status(404).send("Product not found");
  const product=p.rows[0], qty=Math.max(1,parseInt(quantity||1));
  const total=Number(product.price)*qty;
  const client=await pool.connect();
  try{
    await client.query("BEGIN");
    const o=await client.query("INSERT INTO orders(customer_id,total,address,phone) VALUES($1,$2,$3,$4) RETURNING id",
      [req.session.user.id,total,address,phone]);
    await client.query("INSERT INTO order_items(order_id,product_id,quantity,price) VALUES($1,$2,$3,$4)",
      [o.rows[0].id,product.id,qty,product.price]);
    await client.query("UPDATE products SET stock=GREATEST(stock-$1,0) WHERE id=$2",[qty,product.id]);
    await client.query("COMMIT");
    res.render("success",{orderId:o.rows[0].id,total});
  }catch(e){await client.query("ROLLBACK");res.status(500).send("Order failed");}
  finally{client.release();}
});

app.get("/health",(req,res)=>res.send("Dahashop is running"));

const port=process.env.PORT||10000;
app.listen(port,()=>console.log(`Dahashop running on ${port}`));
